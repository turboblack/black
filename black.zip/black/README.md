# wondercms 2.0 black theme
 is based on a standard template, added some changes, logo, background, button up, and social icons.

there is the possibility of inserting comments, or feedback forms

I will be glad if you come to my site and download also other free scripts, plans, templates, and additions to this wonderful engine

� Turboblack 2018 www.torba.tk



